package trabalhoOrdenacao;

public class Concatenacao {
	 public static void main(String[] args) {
	        //Est� criando duas vari�veis do tipo String e est�o recebendo valores
	        String elemento1 = "Computa��o";
	        String elemento2 = " o progresso da humanidade.";
	        //Estar imprimindo os valores da vari�veis elemento1 e elemento2
	        System.out.println(elemento1 + elemento2);
	    }
	 
	}


