package trabalhoOrdenacao;

public class OperacoesAritmeticas {
	public static void main(String[] args) {
        //Declarando vari�veis
        int i = 37;
        int j = 42;
        double x = 24.475;
        double y = 7.22;
        //Imprimindo os valores das vari�veis
        System.out.println("Valores...");
        System.out.println("i =" + i);
        System.out.println("j =" + j);
        System.out.println("x =" + x);
        System.out.println("y =" + y);
        //Adi��o dos n�meros
        System.out.println("Adi��o...");
        System.out.println("i + j = " + (i + j));
        System.out.println("x + y = " + (x + y));
        //Subtra��o dos n�meros
        System.out.println("Subtra��o...");
        System.out.println("i - j = " + (i - j));
        System.out.println("x - y = " + (x - y));
        //Multiplica��o dos n�meros
        System.out.println("Multiplica��o...");
        System.out.println("i * j = " + (i * j));
        System.out.println("x * y = " + (x * y));
        //Divis�o dos n�meros
        System.out.println("Divis�o...");
        System.out.println("i / j = " + (i / j));
        System.out.println("x / y = " + (x / y));
         //Resto da Divis�o
        System.out.println("Resto da Divis�o...");
        System.out.println("i % j = " + (i % j));
        System.out.println("x % y = " + (x % y));
         //Misturando Opera��es
        System.out.println("Resto da Divis�o...");
        System.out.println("i + j = " + (i + j));
        System.out.println("x * y = " + (x * y));
    }
}
