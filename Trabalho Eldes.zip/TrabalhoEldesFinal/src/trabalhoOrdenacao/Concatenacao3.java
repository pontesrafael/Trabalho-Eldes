package trabalhoOrdenacao;

public class Concatenacao3 {
	public static void main(String[] args) {
        //Criando vari�veis do tipo String
        String palavra1 = "Computa��o - Sistema de informa��o";
        String palavra2 = " � para os forte - positivo e continuo!";
        String concatenar = palavra1 + palavra2;
        //Imprimindo o valor
        System.out.println(concatenar);
        //Criando vari�veis do tipo String
        String resultado = "Resultado da concatena��o com parentese = "+(4+4);
        //Imprimindo o valor
        System.out.println("A soma de 4 + 4 �: "+ resultado);
        
         String resultado2 = "Resultado da concatena��o sem parentese = "+ 4 + 4;
         //Imprimindo o valor
        System.out.println("A soma de 4 + 4 �: "+ resultado2);
        //Criando vari�veis do tipo String
        String concatenacao = ("Estabele�a a concaten��o de atitudes positivas na sua vida.\n"
                + "Organiza��o de metas como em ordena��o de dados.\n"
                + "Estabele�a como um switch com v�rias cases de sucesso.\n"
                + "Caso 1: Determine os objetivos e metas com prazo.\n"
                + "Caso 2: Como  o valor de cada vari�vel, estabele�a o valor ao seu pont�ncial de mudan�a.\n"
                + "Realize um (if) e (else) nas suas escolhas, se a op��o � boa executo.\n"
                + "Se n�o executo outra condi��o melhor.\n"
                + "Como  base na organiza��o orientada a objeto, organize seus objetivos.\n"
                + "Heran�a, herda valor agregado para o crescimento. ");
        //Imprimindo o valor
        System.out.println(concatenacao);
    }
}
