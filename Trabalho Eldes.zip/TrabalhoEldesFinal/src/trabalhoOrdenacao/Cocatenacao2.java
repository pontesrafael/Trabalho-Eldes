package trabalhoOrdenacao;

public class Cocatenacao2 {
	public static void main(String[] args) {
        //Est� criando duas vari�veis do tipo String e est�o recebendo valores
        String elem1 = "Sistema ";
        String elem2 = "de informa��o";
        //Criando uma vari�vel que receba a concatena��o das vari�veis Strings
        String computacao = elem1 + elem2;
        //Imprimindo
        System.out.println(computacao);
    }
 

}
